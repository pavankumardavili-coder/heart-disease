CREATE DATABASE heart_disease_analytics;
USE heart_disease_analytics;

-- Table 1: Heart Disease Clinical Data
CREATE TABLE heartdiseasedata_clean (
    Age INT,
    Sex VARCHAR(10),
    Chest_Pain_Type VARCHAR(50),
    Resting_BP INT,
    Cholesterol INT,
    Fasting_Blood_Sugar_GT120 VARCHAR(5),
    Resting_ECG VARCHAR(50),
    Max_Heart_Rate INT,
    Exercise_Induced_Angina VARCHAR(5),
    Oldpeak FLOAT,
    ST_Slope VARCHAR(20),
    Num_Major_Vessels INT,
    Thalassemia VARCHAR(30),
    Heart_Disease_Diagnosis VARCHAR(10)
);

-- Table 2: Heart Disease Patient Cases in India
CREATE TABLE heartdiseaseindia (
    Patient_ID VARCHAR(20),
    State VARCHAR(50),
    Hospital_Name VARCHAR(100),
    Age INT,
    Gender VARCHAR(10),
    Diagnosis VARCHAR(10),
    Risk_Level VARCHAR(20)
);

-- Table 3: Cardiac Hospitals & Centers
CREATE TABLE hospital_cardiac_center_list (
    Hospital_ID VARCHAR(10),
    Hospital_Name VARCHAR(150),
    Region VARCHAR(50),
    Type VARCHAR(30),
    Cardiac_Cath_Lab VARCHAR(5),
    ICU_Beds INT,
    City VARCHAR(50),
    Latitude DOUBLE,
    Longitude DOUBLE
);

-- Table 4: High Risk Patients / Treatment Cost Database
CREATE TABLE highriskpatients_heartdiseasedatabase (
    Risk_Category VARCHAR(50),
    Typical_Procedure VARCHAR(100),
    Treatment_Cost_Min_INR FLOAT,
    Treatment_Cost_Max_INR FLOAT,
    Avg_Recovery_Days INT
);
