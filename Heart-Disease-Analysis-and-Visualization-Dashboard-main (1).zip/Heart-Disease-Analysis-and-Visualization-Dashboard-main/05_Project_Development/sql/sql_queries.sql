-- Select database
USE heart_disease_analytics;

-- View first 10 records
SELECT * FROM heartdiseasedata_clean
LIMIT 10;

-- Patients with confirmed heart disease diagnosis
SELECT Age, Sex, Chest_Pain_Type, Cholesterol, Heart_Disease_Diagnosis
FROM heartdiseasedata_clean
WHERE Heart_Disease_Diagnosis = 'Present'
ORDER BY Age DESC;

-- Average cholesterol level by age group
SELECT
    CASE
        WHEN Age < 40 THEN '<40'
        WHEN Age BETWEEN 40 AND 50 THEN '40-50'
        WHEN Age BETWEEN 51 AND 60 THEN '51-60'
        WHEN Age BETWEEN 61 AND 70 THEN '61-70'
        ELSE '70+'
    END AS Age_Group,
    ROUND(AVG(Cholesterol), 2) AS Average_Cholesterol
FROM heartdiseasedata_clean
GROUP BY Age_Group
ORDER BY Age_Group;

-- Number of patients by chest pain type
SELECT Chest_Pain_Type,
       COUNT(*) AS Total_Patients
FROM heartdiseasedata_clean
GROUP BY Chest_Pain_Type
ORDER BY Total_Patients DESC;

-- High risk patients (Resting BP > 140 and Cholesterol > 240)
SELECT Age, Sex, Resting_BP, Cholesterol, Heart_Disease_Diagnosis
FROM heartdiseasedata_clean
WHERE Resting_BP > 140 AND Cholesterol > 240
ORDER BY Cholesterol DESC;

-- Patients with exercise-induced angina and low max heart rate
SELECT Age, Sex, Max_Heart_Rate, Exercise_Induced_Angina
FROM heartdiseasedata_clean
WHERE Exercise_Induced_Angina = 'Yes' AND Max_Heart_Rate < 120
ORDER BY Max_Heart_Rate ASC;

-- Diagnosis rate by gender
SELECT Sex,
       Heart_Disease_Diagnosis,
       COUNT(*) AS Total_Patients
FROM heartdiseasedata_clean
GROUP BY Sex, Heart_Disease_Diagnosis
ORDER BY Sex;

-- Cardiac hospitals by region and type
SELECT Region, Type,
       COUNT(*) AS Total_Hospitals
FROM hospital_cardiac_center_list
GROUP BY Region, Type
ORDER BY Total_Hospitals DESC;

-- Average treatment cost by risk category
SELECT Risk_Category,
       ROUND(AVG(Treatment_Cost_Min_INR), 2) AS Avg_Min_Cost,
       ROUND(AVG(Treatment_Cost_Max_INR), 2) AS Avg_Max_Cost,
       ROUND(AVG(Avg_Recovery_Days), 1) AS Avg_Recovery_Days
FROM highriskpatients_heartdiseasedatabase
GROUP BY Risk_Category
ORDER BY Avg_Max_Cost DESC;

-- Patient case count by state (India)
SELECT State,
       COUNT(*) AS Total_Cases,
       SUM(CASE WHEN Diagnosis = 'Present' THEN 1 ELSE 0 END) AS Confirmed_Cases
FROM heartdiseaseindia
GROUP BY State
ORDER BY Confirmed_Cases DESC;
